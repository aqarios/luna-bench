from dependency_injector.wiring import Provide, inject
from returns.result import Result

from luna_bench._internal.dao import DaoContainer, DaoTransaction
from luna_bench.errors.dao.data_not_exist_error import DataNotExistError
from luna_bench.errors.unknown_error import UnknownLunaBenchError

from .protocols import ModelSetDeleteUc


class ModelSetDeleteUcImpl(ModelSetDeleteUc):
    """Implementation of the use case for deleting a model set."""

    _transaction: DaoTransaction

    @inject
    def __init__(self, transaction: DaoTransaction = Provide[DaoContainer.transaction]) -> None:
        """
        Initialize the ModelSetDeleteUcImpl with a dao transaction.

        Parameters
        ----------
        transaction : DaoTransaction
            The transaction object used to interact with the dao.
        """
        self._transaction = transaction

    def __call__(self, modelset_name: str) -> Result[None, DataNotExistError | UnknownLunaBenchError]:
        """
        Delete a model set.

        Permanently removes the specified model set from the database.

        Parameters
        ----------
        modelset_name : str
            The name of the model set to delete.

        Returns
        -------
        Result[None, DataNotExistError | UnknownLunaBenchError]
            On success: Nothing
            On failure: An Exception
        """
        with self._transaction as t:
            return t.modelset.delete(modelset_name=modelset_name)
