from __future__ import annotations

from typing import TYPE_CHECKING, cast

from luna_quantum import Logging
from peewee import DoesNotExist, ForeignKeyField, IntegrityError
from returns.result import Failure, Result, Success

from luna_bench._internal.domain_models import ModelMetadataDomain, ModelSetDomain
from luna_bench.errors.dao.data_not_exist_error import DataNotExistError
from luna_bench.errors.dao.data_not_unique_error import DataNotUniqueError
from luna_bench.errors.unknown_error import UnknownLunaBenchError

from .model_sql_dao import ModelSqlDao
from .protocols import ModelSetDao
from .tables import ModelMetadataTable, ModelSetTable

if TYPE_CHECKING:
    from logging import Logger


class ModelSetSqlDao(ModelSetDao):
    _logger: Logger = Logging.get_logger(__name__)

    @staticmethod
    def create(modelset_name: str) -> Result[ModelSetDomain, DataNotUniqueError | UnknownLunaBenchError]:
        modelset = ModelSetTable(name=modelset_name)
        try:
            modelset.save()
            return Success(ModelSetSqlDao.modelset_to_domain(modelset))

        except IntegrityError:
            return Failure(DataNotUniqueError())
        except Exception as e:  # pragma: no cover
            return Failure(UnknownLunaBenchError(e))

    @staticmethod
    def load(modelset_name: str) -> Result[ModelSetDomain, DataNotExistError | UnknownLunaBenchError]:
        try:
            modelset = (ModelSetTable.select(ModelSetTable).where(ModelSetTable.name == modelset_name)).get()  # type: ignore[no-untyped-call]

            return Success(ModelSetSqlDao.modelset_to_domain(modelset))
        except DoesNotExist:
            return Failure(DataNotExistError())
        except Exception as e:  # pragma: no cover
            ModelSetSqlDao._logger.debug(e)
            return Failure(UnknownLunaBenchError(e))

    @staticmethod
    def delete(modelset_name: str) -> Result[None, DataNotExistError | UnknownLunaBenchError]:
        try:
            modelset = ModelSetTable.get(ModelSetTable.name == modelset_name)  # type: ignore[no-untyped-call]

            models_to_check = list(modelset.models)

            modelset.delete_instance(recursive=True)

            # Check if there are any 'lose' models we need to clean up.
            for model in models_to_check:
                if not model.modelsets.exists():
                    model.delete_instance(recursive=True)

            return Success(None)
        except DoesNotExist:
            return Failure(DataNotExistError())
        except Exception as e:  # pragma: no cover
            ModelSetSqlDao._logger.debug(e)
            return Failure(UnknownLunaBenchError(e))

    @staticmethod
    def add_model(
        modelset_name: str, model_id: int
    ) -> Result[ModelSetDomain, DataNotExistError | UnknownLunaBenchError]:
        try:
            modelset = ModelSetTable.get(ModelSetTable.name == modelset_name)  # type: ignore[no-untyped-call]
            model_metadata = ModelMetadataTable.get(ModelMetadataTable.id == model_id)  # type: ignore[no-untyped-call]

            if model_metadata not in modelset.models:
                modelset.models.add(model_metadata)
                modelset.save()

            return Success(ModelSetSqlDao.modelset_to_domain(modelset))
        except DoesNotExist:
            return Failure(DataNotExistError())
        except Exception as e:  # pragma: no cover
            ModelSetSqlDao._logger.debug(e)
            return Failure(UnknownLunaBenchError(e))

    @staticmethod
    def remove_model(
        modelset_name: str, model_id: int
    ) -> Result[ModelSetDomain, DataNotExistError | UnknownLunaBenchError]:
        try:
            modelset = ModelSetTable.get(ModelSetTable.name == modelset_name)  # type: ignore[no-untyped-call]
            model_metadata = ModelMetadataTable.get(ModelMetadataTable.id == model_id)  # type: ignore[no-untyped-call]
            modelset.models.remove(model_metadata)
            modelset.save()
            to_return = ModelSetSqlDao.modelset_to_domain(modelset)
            through_model = ModelSetTable.models.get_through_model()  # type: ignore[no-untyped-call]
            remaining_count = through_model.select().where(through_model.modelmetadatatable == through_model.id).count()

            if remaining_count == 0:
                model_metadata.delete_instance(recursive=True)

            return Success(to_return)
        except DoesNotExist:
            return Failure(DataNotExistError())
        except Exception as e:  # pragma: no cover
            ModelSetSqlDao._logger.debug(e)
            return Failure(UnknownLunaBenchError(e))

    @staticmethod
    def load_all() -> Result[list[ModelSetDomain], UnknownLunaBenchError]:
        try:
            modelsets = ModelSetTable.select()  # type: ignore[no-untyped-call]
            return Success([ModelSetSqlDao.modelset_to_domain(m) for m in modelsets])
        except Exception as e:  # pragma: no cover
            ModelSetSqlDao._logger.debug(e)
            return Failure(UnknownLunaBenchError(e))

    @staticmethod
    def load_all_models(
        modelset_name: str,
    ) -> Result[list[ModelMetadataDomain], DataNotExistError | UnknownLunaBenchError]:
        try:
            modelset = ModelSetTable.get(ModelSetTable.name == modelset_name)  # type: ignore[no-untyped-call]

            return Success([ModelSqlDao.model_to_domain(m) for m in modelset.models])
        except DoesNotExist:
            return Failure(DataNotExistError())
        except Exception as e:  # pragma: no cover
            ModelSetSqlDao._logger.debug(e)
            return Failure(UnknownLunaBenchError(e))

    @staticmethod
    def modelset_to_domain(modelset: ModelSetTable | ForeignKeyField) -> ModelSetDomain:
        return ModelSetDomain(
            id=cast("int", modelset.id),
            name=cast("str", modelset.name),
            models=[ModelSqlDao.model_to_domain(m) for m in modelset.models],
        )
